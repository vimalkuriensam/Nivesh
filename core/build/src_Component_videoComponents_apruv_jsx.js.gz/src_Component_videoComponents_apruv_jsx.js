"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkNivesh"] = self["webpackChunkNivesh"] || []).push([["src_Component_videoComponents_apruv_jsx"],{

/***/ "./src/Component/videoComponents/apruv.jsx":
/*!*************************************************!*\
  !*** ./src/Component/videoComponents/apruv.jsx ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var _Layouts_Home_Videos_Partner_mp4__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../Layouts/Home/Videos/Partner.mp4 */ \"./src/Layouts/Home/Videos/Partner.mp4\");\n/* harmony import */ var _Apruv_webp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Apruv.webp */ \"./src/Component/videoComponents/Apruv.webp\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ \"./node_modules/react/jsx-runtime.js\");\n\n\n\n\n\nvar homeyashwantImage = function homeyashwantImage() {\n  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(\"video\", {\n    className: \"video-fluid z-depth-1\",\n    loop: true,\n    controls: \"true\",\n    muted: true,\n    preload: \"metadata\",\n    playsInline: true,\n    poster: _Apruv_webp__WEBPACK_IMPORTED_MODULE_2__[\"default\"],\n    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(\"source\", {\n      src: _Layouts_Home_Videos_Partner_mp4__WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n      type: \"video/mp4\"\n    })\n  });\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (homeyashwantImage);\n\n//# sourceURL=webpack://Nivesh/./src/Component/videoComponents/apruv.jsx?");

/***/ }),

/***/ "./src/Component/videoComponents/Apruv.webp":
/*!**************************************************!*\
  !*** ./src/Component/videoComponents/Apruv.webp ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (__webpack_require__.p + \"c04e5da58adfc562e37f8952b0865a8a.webp\");\n\n//# sourceURL=webpack://Nivesh/./src/Component/videoComponents/Apruv.webp?");

/***/ }),

/***/ "./src/Layouts/Home/Videos/Partner.mp4":
/*!*********************************************!*\
  !*** ./src/Layouts/Home/Videos/Partner.mp4 ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (__webpack_require__.p + \"1ad944708bdb65ad543ea39c9ee96210.mp4\");\n\n//# sourceURL=webpack://Nivesh/./src/Layouts/Home/Videos/Partner.mp4?");

/***/ })

}]);