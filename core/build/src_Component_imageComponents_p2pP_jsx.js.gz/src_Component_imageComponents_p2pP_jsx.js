"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkNivesh"] = self["webpackChunkNivesh"] || []).push([["src_Component_imageComponents_p2pP_jsx"],{

/***/ "./src/Component/imageComponents/p2pP.jsx":
/*!************************************************!*\
  !*** ./src/Component/imageComponents/p2pP.jsx ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var _images_peer_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./images/peer.svg */ \"./src/Component/imageComponents/images/peer.svg\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ \"./node_modules/react/jsx-runtime.js\");\n\n\n\n\nvar homep2pPImage = function homep2pPImage() {\n  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(\"img\", {\n    loading: \"lazy\",\n    src: _images_peer_svg__WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n    alt: \"\",\n    className: \"img-fluid\"\n  });\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (homep2pPImage);\n\n//# sourceURL=webpack://Nivesh/./src/Component/imageComponents/p2pP.jsx?");

/***/ }),

/***/ "./src/Component/imageComponents/images/peer.svg":
/*!*******************************************************!*\
  !*** ./src/Component/imageComponents/images/peer.svg ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (__webpack_require__.p + \"db6044d9e7357cb25caeb59230c8d3ac.svg\");\n\n//# sourceURL=webpack://Nivesh/./src/Component/imageComponents/images/peer.svg?");

/***/ })

}]);